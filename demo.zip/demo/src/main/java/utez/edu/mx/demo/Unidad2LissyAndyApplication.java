package utez.edu.mx.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Unidad2LissyAndyApplication {

	public static void main(String[] args) {
		SpringApplication.run(Unidad2LissyAndyApplication.class, args);
	}

}
