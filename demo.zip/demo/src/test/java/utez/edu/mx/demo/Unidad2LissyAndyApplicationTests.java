package utez.edu.mx.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Unidad2LissyAndyApplicationTests {

	@Test
	void contextLoads() {
	}

}
